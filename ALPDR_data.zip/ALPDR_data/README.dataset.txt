# ALPDR > 2024-08-13 12:43pm
https://universe.roboflow.com/alpdr/alpdr-akgky

Provided by a Roboflow user
License: CC BY 4.0

